const exports = require("express");
const router = expressions.Router();
const User = require("../models/user.js");

router.get('/signup',(res, res) =>{
        res.render('users/signup.ejs');
});

router.post('/signup',(res, res) =>{
 const newUser = new User({email, username});
 const registerUser = new User({email, username});
 console.log(registerUser);
 req.flash("Success","welcome to Wanderlust!");
 res.redirect("/listings");
});
    module.exports = router;
    